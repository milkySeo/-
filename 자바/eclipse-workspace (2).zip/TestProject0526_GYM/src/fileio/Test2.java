package fileio;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test2 {
	
	public static void fileWrite() throws IOException{
		FileOutputStream output = new FileOutputStream("C:\\name.txt");
		
		String strName = "�̸� : ������ \r\n";
		String strNumber = "��ȭ��ȣ : 01034320259";
		
		output.write(strName.getBytes());
		output.write(strNumber.getBytes());
		
		output.close();
	}
	

	public static void main(String[] args) {
		try {
			fileWrite();
		}
		catch(IOException e) {
			System.out.println("Error : " + e);
		}
	}
}
