package example;

import java.util.ArrayList;

public class GymAdminArrayList extends GymAdmin{

	ArrayList<GymAdmin> list = new ArrayList<GymAdmin>();
	
	public void addMember(GymAdmin m) {
		list.add(m);
	}
	
	public void showMember() {
		for(GymAdmin value : list) {
			System.out.println(value);
		}
	}
	
	public void deleteMember(int a) {
		list.remove(a);
	}
	
}
