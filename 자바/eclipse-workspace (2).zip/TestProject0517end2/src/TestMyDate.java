
public class TestMyDate {

	public static void main(String[] args) {
		MyDate md = new MyDate(17,05,2021);
		MyDate md1 = new MyDate(17,05,2021);
		
		System.out.println(md.equals(md1));
		System.out.println(md.hashCode());
		System.out.println(md1.hashCode());
	}

}
