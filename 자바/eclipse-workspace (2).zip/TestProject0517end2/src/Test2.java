
public class Test2 {

	public static void main(String[] args) {
		final double PI= 3.141592;
		final String URL = "https://www.naver.com/";
		
		System.out.println(PI);
		System.out.println(URL);
		
	}

}
