
public class Test1 {

	public static void main(String[] args) {
		boolean a = false;
		char b = 'a';
		int c = 20;
		long d = 2147483648l;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}
