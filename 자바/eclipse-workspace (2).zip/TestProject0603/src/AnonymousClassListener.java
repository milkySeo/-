import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class AnonymousClassListener extends JFrame{
	public AnonymousClassListener() {
		setTitle("Action �̺�Ʈ ������ ����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		JButton btn = new JButton("Action");
		c.add(btn);
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton b = (JButton)e.getSource();
				if(b.getText().equals("Action")) {
					b.setText("�׼�");
				}
				else {
					b.setText("Action");
				}
			}
		});
		setSize(350,150);
		setVisible(true);
	}
	
//	public static void main(String[] args) {
//		new IndepClassListener2();
//	}
//	private class MyActionListener implements ActionListener{
//		public void actionPerformed(ActionEvent e) {
//			JButton b = (JButton)e.getSource();
//			if(b.getText().equals("Action")) {
//				b.setText("�׼�");
//			}
//			else {
//				b.setText("Action");
//			}
//			AnonymousClassListener.this.setTitle(b.getText());
//		}
//	}
//	
	public static void main(String[] args) {
		new AnonymousClassListener();
	}
}