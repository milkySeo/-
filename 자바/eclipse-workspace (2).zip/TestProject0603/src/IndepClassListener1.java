import javax.swing.JFrame;

public class IndepClassListener1 extends JFrame{
	public IndepClassListener1() {
		setTitle("Action �̺�Ʈ ������ ����");
		setSize(300,300);
		setVisible(true);
	}
	public static void main(String[] args) {
		new IndepClassListener1();
		
	}
}
