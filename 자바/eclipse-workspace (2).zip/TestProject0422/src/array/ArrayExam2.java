package array;

public class ArrayExam2 {

	public static void main(String[] args) {

		float[] array = new float[] {10.0f, 20.0f, 30.0f};
		
		for(int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	}

}
