package getset.exam;

public class UseFood {

	public static void main(String[] args) {
		Food food = new Food();
		
		food.setName("�����");
		food.setPrice(8000);
		food.setType("�ѽ�");
		
//		food.setName("���");
//		food.setPrice(9000);
//		food.setType("���");
		
	
		System.out.println(food.getName() + food.getPrice() + food.getType());

	}

}
