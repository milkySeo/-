package date;

public class UseDate {

	public static void main(String[] args) {
		MyDate date = new MyDate();
//		date.year = 2021;
//		date.month = 4;
//		date.day = 31;
		
		date.setYear(2021);
		date.setMonth(2);
		date.setDay(28);
		
		System.out.println("�⵵ : " + date.getYear());
		System.out.println("�� : " + date.getMonth());
		System.out.println("�� : " + date.getDay());
		
	}

}
