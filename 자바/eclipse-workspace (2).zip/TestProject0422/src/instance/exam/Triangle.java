package instance.exam;

public class Triangle extends Shape{

	public void draw() {
		System.out.println("Triangle");
		
	}
}
