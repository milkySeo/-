package instance.exam;

public class UseShape {

	public static void main(String[] args) {
		Shape shape = new Circle();
		Shape shape2 = new Triangle();
		
		shape.draw();//Circle ���
		shape2.draw();//Triangle ���
		
		if(shape instanceof Circle) {
			Circle circle = (Circle)shape;//shape�� circle �� �ٽ� ����ȯ
			circle.draw();//Circle ���
		}
		
		if(shape2 instanceof Triangle) {
			Triangle triangle = (Triangle)shape2;
			triangle.draw();//Triangle ���
		}

	}

}
