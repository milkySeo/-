package person;

public class UsePerson {

	public static void main(String[] args) {

		Person person = new Person();
		person.setName("������");
		person.setNumber(1234);
		
		System.out.println(person.getName());
		System.out.println(person.getNumber());
	}

}
