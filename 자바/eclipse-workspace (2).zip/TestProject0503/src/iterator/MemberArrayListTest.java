package iterator;

import java.util.ArrayList;

public class MemberArrayListTest {

	public static void main(String[] args) {
		
		MemberArrayList cls1 = new MemberArrayList();
		
		Member m1 = new Member(111, "��"	);
		Member m2 = new Member(222, "��"	);
		Member m3 = new Member(333, "��"	);
		Member m4 = new Member(444, "��"	);
		Member m5 = new Member(555, "��"	);
		Member m6 = new Member(666, "�� ");
		Member m7 = new Member(777, "�� ");
		
		//cls1.memberList.add(m1);
		
		
		cls1.addMember(m1);
		cls1.addMember(m2);
		cls1.addMember(m3);
		cls1.addMember(m4);
		cls1.addMember(m5);
		
		
//		cls1.removeMember(444);
		
		cls1.removeMember(444);

		//cls1.plusMember(2, m7);
		
		cls1.showAllMember();
		
	}

}
