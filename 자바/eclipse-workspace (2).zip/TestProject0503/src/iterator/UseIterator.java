package iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class UseIterator {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("��");
		list.add("��");
		list.add("��");
		
		Iterator<String> iterator = list.iterator();
		
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
