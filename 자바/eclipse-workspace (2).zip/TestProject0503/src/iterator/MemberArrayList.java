package iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class MemberArrayList extends Member{
	
	ArrayList<Member> memberList= new ArrayList<Member>();

	public void addMember(Member m) {
		memberList.add(m);
		
	}
	//2�����ѹ���ε� �����ε�
//	public void removeMember(Member rmId) {
//		
//		Iterator<Member> iterator = memberList.iterator();
//		while(iterator.hasNext()) {
//			if(iterator.next() == rmId) {
//				iterator.remove();
//			}
//		}
//	}
	
	//	1	for(int i = 0; i < memberList.size(); i++) {
//			Member member = memberList.get(i);
//			member.getMemberId();
//			if(rmId == member.getMemberId()) {
//			memberList.remove(i);
//			}
//		}
	
	//�������� �� ���
	public void removeMember(int rmId) {
		Iterator<Member> iterator = memberList.iterator();
		while(iterator.hasNext()) {
			Member member = iterator.next();
			if(member.getMemberId() == rmId) {
				memberList.remove(member);
			}
			
		}
	
	}	
		
		
	
	public void showAllMember() {
		for(Member value : memberList) {
			System.out.println(value);
		}
	}
	
	
	public void plusMember(int a, Member m) {
		memberList.add(a, m);
		
	}
	
	
	
	
	
	
	

}
