package hashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class UseHashMap {

	public static void main(String[] args) {
//		HashMap<String, String>	hashMap1 = new HashMap<String, String>();
//		hashMap1.put("���", "apple");
//		hashMap1.put("�ٳ���", "banana");
//		//��Ʈ�������� �ƹ�����x
//		System.out.println(hashMap1);
//		
//		HashMap<String, Integer> hashMap2 = new HashMap<String, Integer>();
//		hashMap2.put("number1", 10);
//		hashMap2.put("number2", 20);
//		System.out.println(hashMap2);
//		
		//������Ʈ����ϸ� ��Ʈ, ��Ʈ�� �� ��밡����
		HashMap<String, Object> hashMap3 = new HashMap<String, Object>();
		hashMap3.put("Name", "������");
		hashMap3.put("Age", "25");
		hashMap3.put("Gender", "W");
		//hashMap3.replace("Age", 31);
		
//		for(String key : hashMap3.keySet()) {
//			System.out.println("Ű : " + key + " , �� : " + hashMap3.get(key));
//		}
		
		Iterator<String> iterator = hashMap3.keySet().iterator();
		while(iterator.hasNext()) {
			String key = iterator.next();
			System.out.println("Ű : " + key + " , �� : " + hashMap3.get(key)+"=========1==");
		}
		
		System.out.println(hashMap3);
		
		if(hashMap3.containsKey("NAME")) {
			System.out.println("Name�̶�� ���� ������ �̾��ϴ�.");
		}
		if(hashMap3.containsKey("111111")) {
			System.out.println("111111");
		}
		System.out.println("=========------------==");
		hashMap3.remove("Age");
		
		System.out.println(hashMap3);
		hashMap3.clear();
		System.out.println(hashMap3 + "d");
		
		for(String key : hashMap3.keySet()) {
			System.out.println(key + hashMap3.get(key) + "==============");
		}
		//��������
		//HashMap<String, Object> hashMap3 = new HashMap<String, Object>(hashMap1);
		
		
		//ArrayList�ȿ� HashMap ���
		ArrayList<HashMap<String, Object>> maplist = new ArrayList<HashMap<String, Object>>(); 
	}

}
