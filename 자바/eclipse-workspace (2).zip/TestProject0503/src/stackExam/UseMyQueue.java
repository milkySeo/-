package stackExam;

public class UseMyQueue {

	public static void main(String[] args) {
		MyQueue queue = new MyQueue();
		queue.enQueue("a");
		queue.enQueue("b");
		queue.enQueue("c");
		queue.enQueue("d");
	
		for(String  value : queue.list) {
			System.out.println(value);
			}
		System.out.println("===============");
		
		
		queue.deQueue();
//		queue.deQueue();
//		queue.deQueue();
		
		for(String  value : queue.list) {
			System.out.println(value);
			}
	}

}
