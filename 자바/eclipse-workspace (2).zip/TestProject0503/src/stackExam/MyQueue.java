package stackExam;

import java.util.ArrayList;

public class MyQueue {
	ArrayList<String> list = new ArrayList<String>();
	
	public void enQueue(String a) {
		list.add(a);
	}
	
	public void deQueue() {
		list.remove(0);
	}
}
