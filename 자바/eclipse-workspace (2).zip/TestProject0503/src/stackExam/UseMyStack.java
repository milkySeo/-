package stackExam;

public class UseMyStack {

	public static void main(String[] args) {
		MyStack stack = new MyStack();
		stack.push("a");
		stack.push("b");
		stack.push("c");
		stack.push("d");
		stack.push("e");
		
		//System.out.println(stack.list1.size());
		
		for(String list : stack.list1) {
			System.out.println(list);
		}
		
		
		System.out.println("=================");
		
		stack.pop();
		stack.pop();

		//String�� �޼ҵ��϶��� ����
		//System.out.print(stack.pop());
		
		
		for(String list : stack.list1) {
			System.out.println(list);
		}
		
	}

}
