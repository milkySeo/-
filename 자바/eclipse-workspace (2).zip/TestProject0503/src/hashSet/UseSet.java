package hashSet;

import java.util.HashSet;
import java.util.TreeSet;

public class UseSet {

	public static void main(String[] args) {
		//HashSet �ߺ� ��� x
		HashSet<String> hashSet	= new HashSet<String>();
		hashSet.add("1");
		hashSet.add("1");
		hashSet.add("2");
		hashSet.add("2");
		hashSet.add("3");
		hashSet.add("4");

		System.out.println(hashSet);
		
		//TreeSet �ߺ� ���x, ���ı���
		TreeSet<String> treeSet = new TreeSet<String>();
		treeSet.add("2");
		treeSet.add("3");
		treeSet.add("a");
		treeSet.add("1");
		treeSet.add("c");
		treeSet.add("b");
		treeSet.add("1");
		
		for(String value : treeSet) {
			System.out.println(value);
		}
		
	}

}
