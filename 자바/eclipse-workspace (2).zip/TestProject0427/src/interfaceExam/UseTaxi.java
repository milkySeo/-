package interfaceExam;

public class UseTaxi {

	public static void main(String[] args) {
		Taxi taxi = new Taxi();
		taxi.start();
		taxi.stop(5);
		
		Meter meter = new Taxi();
		meter.start();
		meter.stop(6);
		
		if(meter instanceof Taxi) {
			
		}
	}

}
