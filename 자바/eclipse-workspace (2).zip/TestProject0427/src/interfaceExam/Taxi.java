package interfaceExam;

public class Taxi implements Meter {

	@Override
	public void start() {
		System.out.println("�ý����");
	}

	@Override
	public void stop(int distance) {
		System.out.println("�ýõ���");
		System.out.println("��� : " + distance*2);
	}
	
	public void introduce() {
		System.out.println("���ýô�");
	}
	
}
