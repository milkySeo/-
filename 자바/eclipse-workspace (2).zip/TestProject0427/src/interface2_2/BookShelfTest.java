package interface2_2;

public class BookShelfTest {

	public static void main(String[] args) {

		Queue selfQueue = new BookShelf();//ťŸ������ �Ͻ��� ����
		selfQueue.enqueue("��1");
		selfQueue.enqueue("��2");
		selfQueue.enqueue("��3");
		
		System.out.println(selfQueue.getSize());
		
		selfQueue.dequeue();
		selfQueue.dequeue();
		selfQueue.dequeue();
		
		System.out.println(selfQueue.getSize());
	}

}
