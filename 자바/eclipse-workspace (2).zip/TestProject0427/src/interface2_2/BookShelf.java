package interface2_2;

public class BookShelf extends Shelf implements Queue {

	@Override
	public void enqueue(String title) {
		arrayList.add(title);
	}

	@Override
	public void dequeue() {
		arrayList.remove(0);
	}

	@Override
	public int getSize() {
		return arrayList.size();
	}


}
