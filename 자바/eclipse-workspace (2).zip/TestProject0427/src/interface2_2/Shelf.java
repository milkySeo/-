package interface2_2;

import java.util.ArrayList;

public class Shelf {

	public ArrayList<String> arrayList;
	
	public Shelf() {
		arrayList = new ArrayList<String>();
	}
	
	public ArrayList<String> getShelf(){
		return arrayList;
	}
	
	public int getCount() {
		return arrayList.size();
	}
}
