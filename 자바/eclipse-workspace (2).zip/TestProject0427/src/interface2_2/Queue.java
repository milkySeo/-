package interface2_2;

public interface Queue {
	public void enqueue(String title);
	
	public void dequeue();
	
	public int getSize();
}
