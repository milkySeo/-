package interfaceExam2;

public class Calculator implements Calc {

	@Override
	public void plus(int a , int b) {

		System.out.println(a + b);
	}

	@Override
	public void minus(int a , int b) {

		System.out.println(a - b);
	}

	@Override
	public void multiply(int a , int b) {
		System.out.println(a * b);
	}

	@Override
	public void division(int a , int b) {
		System.out.println(a / b);
	}

	@Override
	public void ho(int a, int b) {
		System.out.println("�ι�°" + a);
		System.out.println("�ι�°" + b);
	}



	
	

}
