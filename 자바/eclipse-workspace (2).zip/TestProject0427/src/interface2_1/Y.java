package interface2_1;

public interface Y {
	public void y();
}
