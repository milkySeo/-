package interface2_1;

public class UseMyClass {

	public static void main(String[] args) {
		MyClass myClass = new MyClass();
		
		X xClass = myClass;
		xClass.x();
		
		Y yClass = myClass;
		yClass.y();
		
		MyInterface iClass = myClass;//��� ��ӹް������ϱ� �Ѵ� ��~!!!
		iClass.myMethod();
		iClass.x();
		iClass.y();
	}

}
