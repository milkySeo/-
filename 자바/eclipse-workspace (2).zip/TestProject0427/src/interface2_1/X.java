package interface2_1;

public interface X {
	public void x();
}
