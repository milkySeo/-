package interface2;

public interface Sell {
	public void sell();
	
	
	public default void order() {
		System.out.println("�Ǹ� �ֹ�");
	}
}
