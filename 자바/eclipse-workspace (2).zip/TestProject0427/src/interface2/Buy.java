package interface2;

public interface Buy {
	public void buy();
	
	public default void order() {
		System.out.println("���� �ֹ�");
	}
}
