//�������� ����
//public class ValableScopeExam {
//	int globalScope = 10;
//	static int staticValue = 10;
//	
//	public void scopeTest1(int value) {
//		int localScope = 10;
//		
//		System.out.println(globalScope);
//		System.out.println(localScope);
//		System.out.println(value);
//		System.out.println(staticValue);
//	}
//	
//	public static void main(String[] args) {
//		System.out.println(globalTest);
//		System.out.println(localScope);
//		System.out.println(value);
//		System.out.println(staticValue);
//	}
//}

