//enum Gender {
//	MAIL, FEMAIL
//}
//
//public class EnumSample {
//	
//	public static void main(String[] args) {
//		Gender gender;
//		
//		gender = Gender.MAIL;
//		System.out.println(gender);
//		
//		gender = Gender.FEMAIL;
//		System.out.println(gender);
//		
//	}
//}
//////////////////////////////////////

enum Season{
	SPRING, SUMMER, AUTUM, WINTER
	//�ѱ۷ε� ����
}

//public class Enum0419{
//	
//	public static void main(String[] args) {
//		String name = "������";
//	
//		Season season;
//	
//		season = Season.SUMMER;
//	
//		System.out.println(season);
//		System.out.println(name);
//	
//	}
//}
public class Enum0419{
	String name;
	Season season;
	
	public static void main(String[] args) {
		Enum0419 enumex = new Enum0419();
		enumex.name = "������";
		enumex.season = Season.SUMMER;
		
		System.out.println(enumex.name);
		System.out.println(enumex.season);
		
	}
}

