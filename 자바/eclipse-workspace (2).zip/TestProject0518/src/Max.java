import java.util.Scanner;

public class Max {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
//		int a = scan.nextInt();
//		int b = scan.nextInt();
//		int c = scan.nextInt();
//		int m;
		
//		if(a > b) {
//			m = a;
//		}
		
		int a = scan.nextInt();
		int i = 0;
		int sum = 0;
		while(i <= a) {
			if(i % 2 == 0) {
				sum = sum + i;
				i++;
			}
			i++;
		}
		System.out.println(sum);
		
		
		
	}
}
