import java.util.Scanner;

public class Test3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int a = scan.nextInt();
		
		for(int i = 0; i < 5; i++) {
			//for(int j = 5; 2 * j - 1) > 0; j--) {//j = 5 -> 9
				
		}
	}
	

}
