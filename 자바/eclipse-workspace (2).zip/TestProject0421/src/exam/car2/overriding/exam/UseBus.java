package exam.car2.overriding.exam;

public class UseBus {

	public static void main(String[] args) {
		Bus bus = new Bus();
		bus.run();
		bus.stop();
		bus.horn();
		

	}

}
