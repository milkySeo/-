package exam1.car���1;

public class UseCar {

	
	public static void main(String[] args) {
		Car car = new Car();
		car.turnOn();
		car.turnOff();

	}
	

}
