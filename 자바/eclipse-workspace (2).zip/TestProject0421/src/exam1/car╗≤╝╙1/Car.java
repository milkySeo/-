package exam1.car���1;

public class Car extends CarState {

	

}
