package exam2���2;

public class UseStudent {

	public static void main(String[] args) {
		Student student = new Student();
		student.name = "������";
		student.height = 174;
		student.weight = 64;
		student.gender = "����";
		
		student.showPersonInfo();

	}

}
