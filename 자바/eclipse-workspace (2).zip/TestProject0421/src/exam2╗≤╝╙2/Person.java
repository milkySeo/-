package exam2���2;

public class Person {

	String name;
	int height;
	int weight;
	String gender;
	
	public void showPersonInfo() {
		System.out.println("�̸� : " + name);
		System.out.println("Ű : " + height);
		System.out.println("������ : " + weight);
		System.out.println("���� : " + gender);

	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
