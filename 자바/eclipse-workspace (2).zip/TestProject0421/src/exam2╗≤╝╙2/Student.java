package exam2���2;

public class Student extends Person{

	public static void main(String[] args) {
		

	}

}
