package Abstract;

public class UseCar {

	public static void main(String[] args) {
		Car car = new Car();
		car.turnOn();
		car.turnOff();

	}

}
