package Abstract;

public class Duck extends Bird{

	@Override
	public void sing() {
		System.out.println("�в�!");
		

	}

}
