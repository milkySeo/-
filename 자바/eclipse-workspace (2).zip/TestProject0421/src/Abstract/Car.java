package Abstract;

public class Car extends Machine {

	@Override
	public void turnOn() {
		System.out.println("�õ�����");
	}
	
}
