package Access;

public class CarExam {

	public static void main(String[] args) {
		Car car = new Car("�ƿ��", 1234);
		
		System.out.println("name : " + car.name);
		System.out.println("number : " + car.number);
	}

}
