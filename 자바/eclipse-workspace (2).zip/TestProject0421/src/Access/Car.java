package Access;

public class Car {

	String name;
	protected int number;
	
	public Car(String name, int number) {
		this.name = name;
		this.number = number;
	}
}
