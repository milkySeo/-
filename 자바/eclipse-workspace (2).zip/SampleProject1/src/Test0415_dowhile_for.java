
public class Test0415_dowhile_for {

	public static void main(String[] args) {
//		///¦���� �հ� Ȧ���� ��////�ٽ�!!!!!!!!////////////////////////////////////////
//		int i = 1;
//		int sum1 = 0;
//		int sum2 = 0;
//		
//		while(i <= 10) {
//			
//			if(i%2==0) {
//				sum1 = sum1 + i;
//			}
//			else {
//				sum2 = sum2 + i;
//			}
//			i++;
//		}
//		
//		System.out.println("¦���� ���� : " + sum1 + " Ȧ���� ���� : " + sum2);

		
//		////do-while �� ����ؼ� 100���� 1����/////////////////////////////////////
//		int i = 100;
//		
//		do {
//			System.out.println(i--);
//			
//		} while(i >= 1);
		////////��Ģ������� if-else��/ switch-case�� �����//////////////////////////
		
//		int num1 = 10;
//		int num2 = 2;
//		int num3 = 0;
//		char operator = '/';
//		
//		
//		if(operator == '+') {
//			num3 = num1 + num2;
//		}
//		else if(operator == '-') {
//			num3 = num1 - num2;
//		}
//		else if(operator == '*') {
//			num3 = num1 * num2;
//		}
//		else if(operator == '/') {
//			num3 = num1 / num2;
//		}
//		System.out.println(num3);
//		
//		switch(operator) {
//		case '+':
//			num3 = num1 + num2;
//			break;
//		case '-':
//			num3 = num1 - num2;
//			break;
//		case '*':
//			num3 = num1 * num2;
//			break;
//		case '/':
//			num3 = num1 / num2;
//			break;
//		}
//		System.out.println(num3);
		///////////////for�� �ǽ�!//////////////////////////////////////////////
//		int sum = 0;
//		int sum1 = 0;
//		for(int i = 1; i <= 100; i++) {
//			
//			sum += i;
//		}
//		System.out.println("1���� 100���� �հ� : " + sum);
//		
//		
//		for(int j = 1; j <= 100; j++) {
//			if(j % 2 == 0) {
//				System.out.println("¦���� ��� : " + j);
//			}
//		}
//		
//		for(int k =1; k <= 100; k++) {
//			if(k % 2 == 1) 
//				continue;
//			sum1 += k;
//		}
//		System.out.println("¦���� �� : " + sum1);
		///////////////����for��///////////////////////////////////////////
//		for(int i = 1;i <= 25; i++) {
//			if(i % 5 == 0) {
//				System.out.println("��");
//			}
//			else {
//				System.out.print("��");
//			}
//			
//		}
//		
//		for(int i = 1; i<=5 ; i++) {
//			for(int k = 1; k <= 4; k++) {
//				System.out.print("��");
//			}
//			System.out.println("��");
//		}
		//////////////////////////////////////////////////////////////////
//		for(int i = 1; i <= 3; i++) {
//			for(int k = 1; k <= 7; k++) {
//				System.out.print("��");
//			}
//			System.out.println();
//		}
		
		///////////������!////////////////
//		for(int i = 1; i <= 9; i++) {
//			for(int k = 1; k <= 9; k++) {
//				System.out.println(i + " * " + k + " = " + i*k);
//			}
//		}
		
//		for(int i = 1; i <= 9; i++) {
//			if(i % 2 != 0) 
//				continue;
//			for(int k = 1; k <= 9; k++) {
//				
//				System.out.println(i + " * " + k + " = " + i*k);
//			}
//			
//		}
		
		////////////////////////////////���׸�///////////////�̰� ������� �ٽ��ؾ߉�
		
		for (int i = 1; i <= 5; i++){
			
			for(int j = 0; j <= 4-i; j++) { //4 3 2 1 0
				System.out.print("��");
			}
			
			for(int j = 1; j <= i; j++ ) { //1 2 3 4 5
				System.out.print("��");
			}
			System.out.println();
			
			
		}
		
		/////////////////////////////////�Ƕ�̵庰////////////
		
		for(int i = 1; i <= 4; i++) {
			for(int j = 1; j <= 4-i; j++) {  //3 2 1 0
				System.out.print(" ");
			}
			
			for(int s = 1; s <= i*2-1; s++) { //1 3 5 7
				System.out.print("*");
			}
			
			for(int j = 1; j <= 4-i; j++) {  //3 2 1 0
				System.out.print(" ");
			}
			System.out.println("");
		}
		
		
	}

}
