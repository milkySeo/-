
public class Test0412 {

	public static void main(String[] args)
	{
		//int count = 10;
		//System.out.println(count);
		
		//int number;
		//number =3;
		//System.out.println(number);
		
//		int tempNumber1 = 10;
//		
//		int tempNumber2;
//		tempNumber2 = 10;
//		
//		System.out.println(tempNumber1);
		
//		boolean isTrue = false;
//		char a = 'a';
//		int cnt1 = 20;
//		long cnt2 = 2147483648l;
//		
//		System.out.println(isTrue);
//		System.out.println(a);
//		System.out.println(cnt1);
//		System.out.println(cnt2);

//		int apple = 3000;
//		int pear = 5000;
//		int strberry = 9000;
//		
//		boolean isWoman = true;
//		
//		System.out.println(isWoman);
		
//		byte bNum = 10;
//		int iNum = bNum;
//		
//		System.out.println(bNum);//10
//		System.out.println(iNum);//10
//		
//		int iNum2 = 20;
//		float fNum = iNum2;
//		
//		System.out.println(iNum2);//20
//		System.out.println(fNum);//20.0
//		
//		double dNum;
//		dNum = fNum+iNum;
//		
//		System.out.println(dNum);//30
//		
		
//		long number1 = 12345678910L;
//		int number2 = (int)number1;
//		
//		System.out.println(number1);
//		System.out.println(number2);
		
//		double dNum = 3.14;
//		int dNum1 = (int)dNum;
//		
//		System.out.println(dNum1);
//		
//		
//		int iNum = 100;
//		double iNum1 = (double)iNum;
//		
//		System.out.println(iNum1);
		
		double dNum1 = 1.2;
		float fNum2 = 0.9f;
		
		int iNum3 = (int)dNum1 +(int)fNum2;
		int iNum4 = (int)(dNum1 + fNum2);
		
		System.out.println(iNum3);//1
		System.out.println(iNum4);//2

		 
	}

}
