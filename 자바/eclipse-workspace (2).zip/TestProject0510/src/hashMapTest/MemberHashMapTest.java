package hashMapTest;

public class MemberHashMapTest {
	public static void main(String[] args) {
		MemberHashMap mHash = new MemberHashMap();
		mHash.addMember(1, "�趯��");
		mHash.addMember(2, "�̶���");
		mHash.addMember(3, "�ڶ���");
		mHash.addMember(4, "�ֶ���");
		
		mHash.showAllMember();
		
		mHash.removeMember(2);
		
		System.out.println("=======================");
		mHash.showAllMember();
	}
}	
