package hashMapTest;

import java.util.HashMap;
import java.util.Iterator;

public class MemberHashMap1 extends Member{
	HashMap<Integer, Member> member1 = new HashMap<Integer, Member>();
//	Iterator<Integer> iterator = member1.keySet().iterator();
//	int key = iterator.next();
	
	public void addMember(Member member) {
		member1.put(member.getMemberId(), member);
	}
	
	public boolean removeMember(int memberId) {
		if(member1.containsKey(memberId)) {
			member1.remove(memberId);
			return true;
		}
		
		System.out.println(memberId + "�� �������� �ʽ��ϴ�.");
		return false;
		
	}
	
	public void showAllMember() {
		Iterator<Integer> iterator = member1.keySet().iterator();
		while(iterator.hasNext()) {
			int key = iterator.next();
			
			Member member2 = member1.get(key);
			
			System.out.println(member2);
			//System.out.println("ID : " + key + ", �̸� : " + member.get(key));
		}
	}
}
