package hashMapTest;

public class MemberHashMapTest1 {

	public static void main(String[] args) {
		MemberHashMap1 mHash = new MemberHashMap1();
		
		Member member1 = new Member(1, "�趯��");
		Member member2 = new Member(2, "�̶���");
		Member member3 = new Member(3, "�ڶ���");
		Member member4 = new Member(4, "�ֶ���");
		
		mHash.addMember(member1);
		mHash.addMember(member2);
		mHash.addMember(member3);
		mHash.addMember(member4);
		
		mHash.showAllMember();
		
		mHash.removeMember(1);
		System.out.println("========================");
		mHash.showAllMember();
		

	}

}
