package exception2;

import exception.Exception;

public class UseBiz {
	public static void main(String[] args) {
		BizService bizService = new BizService();
		
		bizService.bizMethod(10);
		try {
			bizService.bizMethod(-3);
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
	}
}
