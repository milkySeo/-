package exception2;

public class MyCheckedException2 {
	 public static void main(String[] args) {
		 int[]array = {1,2,3};
		 
		 try {
			 get50thItem(array);
		 
		 }
		 catch(Exception e) {
			 System.out.println(e.toString());
			 
		 }
		 
		 System.out.println("���ι�����");
		 
		 public static int get50thItem(int []array) throws ArrayIndexOutOfBoundsException{
			if(array.length < 50) {	
				Exception e = new Exception("�迭�� ũ�Ⱑ 50���� �۽��ϴ�.");
				throw new MyCheckedException(e);
			}
		
			return array[49];
		 }
		 
	 }
}
