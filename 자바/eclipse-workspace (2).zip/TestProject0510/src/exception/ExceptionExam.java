package exception;

public class ExceptionExam {

	public static void main(String[] args) {
		int[] array = {1, 2, 3};
		array[0] = 5;
		
		try {
			System.out.println(array[1]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("�����߻�  / " + e.toString());
		}
		finally{
			System.out.println("============");
		}
	}
	
	

}
