package exception;

public class ExceptionExam2 {

	public static void main(String[] args) {
		int[] array = {1, 2, 3};
		try {
			get50thItem(array);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e.toString());
		}
	}
	
	
	public static int get50thItem(int []array) throws ArrayIndexOutOfBoundsException{
		if(array.length < 50) {
			return array[49];
		}
		return array[49];
	}
	
		


}
