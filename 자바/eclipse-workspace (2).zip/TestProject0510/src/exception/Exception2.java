package exception;

public class Exception2 {

	
	public static void main(String[] args) {
		int a = 10;
		int b = 0;
		
		try {
			int c = divide(a,b);
			System.out.println(c);
		}
		catch(ArithmeticException e) {
			System.out.println(e.toString());
			
		}
		System.out.println("main�� ����");
		
	
	}


	public static int divide(int n1,int n2) throws ArithmeticException {
		int n3 = n1/n2;
		return n3;
	}
}