package Generic2;

public class EmployeeInfo extends Info {

	public int rank;
	
	public EmployeeInfo(int rank) {
		this.rank = rank;
	}
	
}
