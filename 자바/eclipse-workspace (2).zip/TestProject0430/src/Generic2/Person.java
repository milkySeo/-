package Generic2;

public class Person<T extends Info2> {

	public T info;
	
	public Person(T info) {
		this.info = info;
	}
	
}
