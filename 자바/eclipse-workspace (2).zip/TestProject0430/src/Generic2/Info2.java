package Generic2;

public interface Info2 {

}
