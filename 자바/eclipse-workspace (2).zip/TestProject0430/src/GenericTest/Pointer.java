package GenericTest;

public class Pointer {

	public static void main(String[] args) {
		Point<Double, Integer> point1 = new Point<Double, Integer>(3.0, 4);
		System.out.println(point1.x);
		System.out.println(point1.getX());
		System.out.println(point1.getY());
	}

}
