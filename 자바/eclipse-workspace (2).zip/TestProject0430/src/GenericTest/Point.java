package GenericTest;

public class Point<T, S> {
	public T x;
	public S y;
	
	public Point(T x, S y) {//�̰Žû����ڿ�
		this.x = x;
		this.y = y;
	}
	
	public T getX() {
		return x;
	}
	
	public S getY() {
		return y;
	}
	
	
}
