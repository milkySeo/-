package example1;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EventRegist {
	Scanner scanner = new Scanner(System.in);
	
	
	String jdbcDriver = "com.mysql.cj.jdbc.Driver";
	String jdvcUrl = "jdbc:mysql://localhost";
	Connection conn;
	
	PreparedStatement pstmt;
	Statement stmt;
	ResultSet rs;
	
	String uname, email,yesNo;
	
	public EventRegist() {
		connectDB();
		
		while(true) {
			
			System.out.println("1�� : ��� \n2�� : ��ȸ \n3�� : ���� \n4�� : ����");
			int casenum = scanner.nextInt();
			switch(casenum) {
			case 1 :
				inputData();
				break;
			case 2 : 
				printList();
				break;
			case 3 :
				deleteData();
				break;
			case 4 :
				closeDB();
				break;
			}
		}
		
		
	}
	
	public void connectDB() {
		try {
			Class.forName(jdbcDriver);
			
			//conn = DriverManager.getConnection(jdvcUrl ,"root","0259");
			//createDB();
			conn = DriverManager.getConnection(jdvcUrl + "/javadb","root","0259");
			System.out.println("DB ����");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void createDB() {
		try {
			Statement stmt = conn.createStatement();
			stmt.executeUpdate("create database if not exists javadb");
			stmt.executeUpdate("use javadb");
			String Str_sql = "create table event (uname varchar(30) not null, email varchar(30) not null, primary key(uname));";
			stmt.executeUpdate(Str_sql);
			stmt.close();
			System.out.println("create");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void closeDB() {
		try {
			pstmt.close();
			rs.close();
			conn.close();
			System.out.println("����");
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void inputData() {
		while(true) {
			System.out.println("##�̺�Ʈ ����� ���� �̸��� �̸����� �Է��ϼ���");
			System.out.println("�̸� : ");
			uname = scanner.next();
			System.out.println("�̸��� : ");
			email = scanner.next();
			registUser(uname,email);
			System.out.println("����Ͻ÷��� Y/y�� ��������");
			yesNo = scanner.next();
			if(yesNo.equals("Y")|yesNo.equals("y"))
				continue;
			else
				break;
		}
	}
	
	public void registUser(String uname,String email) {
		String sql = "insert into event values(?,?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, uname);
			pstmt.setString(2, email);
			pstmt.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void printList() {
		System.out.println("��ȸ# ����� ����");
		String sql = "select * from event";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				System.out.println("�̸� : " + rs.getString("uname"));
				System.out.println("�̸��� : " + rs.getString("email"));
				System.out.println("------------------------");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteData() {
		System.out.println("�����͸� ����ðڽ��ϱ�?(Y/y)");
		yesNo = scanner.next();
		if(yesNo.equals("Y")|yesNo.equals("y")) {
			String sql = "select * from event";
			try {
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				System.out.print("�̸� : ");
				while(rs.next()) {
					System.out.print(rs.getString("uname") + ", ");
				}
				System.out.println("\n ����� ���� �̸��� ��Ȯ�ϰ� �Է��ϼ���");
				String dname = scanner.next();
				int count = pstmt.executeUpdate("delete from event where uname = '"+dname+"'");
				System.out.println(count + "���� �������ϴ�.");
				System.out.println();
				printList();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		new EventRegist();
	}
}


