package example1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BookList {
	Connection con;
	
	public BookList() {
		String driver = "";
		String url = "jdbc:mysql://localhost:3306/bookstore";
		String userid="root";
		String pwd = "0259";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("����̹� �ε� ����");
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		
		try {
			System.out.println("�����ͺ��̽� ���� �غ�...");
			con=DriverManager.getConnection(url,userid,pwd);
			System.out.println("�������̽� ���� ����");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public void sqlRun() {
		String query="select * from book";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			System.out.println("Bookno/ book name/ publisher/ price");
			while(rs.next()) {
				System.out.print("  " + rs.getString("bookid") + "    ");
				System.out.print(rs.getString("bookname") + "     ");
				System.out.print(rs.getString("publisher") + "     ");
				System.out.println(rs.getInt("price"));
			}
			con.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public static void main(String args[]) {
		BookList so = new BookList();
		so.sqlRun();
	}
}
