package example1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbc2 {

	public static void main(String[] args) {
		Connection conn;
		Statement stmt = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledb","root","0259");
			System.out.println("DB ���� �Ϸ�");
			stmt = conn.createStatement();
			System.out.println("-------------1");
			stmt.executeUpdate("insert into student(name, id, dept) values('�ƹ���','00005','��ǻ�Ͱ��а�');");
			System.out.println("---------2");
			printTable(stmt);
			
			System.out.println("���̵�ٲٰ�-----------3");
			stmt.executeUpdate("update student set id='00006' where name = '�ƹ���'");
			printTable(stmt);
			System.out.println("���������--------------");
			stmt.executeUpdate("delete from student where name = '�ƹ���'");
			printTable(stmt);
			}
		catch(ClassNotFoundException e) {
			System.out.println("JDBC ����̹� �ε� ����");
		}
		catch(SQLException e) {
			System.out.println("sql �������");
		}
	}

	private static void printTable(Statement stmt) throws SQLException {
		ResultSet srs = stmt.executeQuery("select * from student");
		while(srs.next()) {
			System.out.print(srs.getString("name") + " ");
			System.out.print(srs.getString("id") + " ");
			System.out.println(srs.getString("dept"));
		}
		
	}


}


