package classClass;

public class UsePerson {////////////�̰� �ä��ƴ�....

	public static void main(String[] args) {
		Person person = new Person("�̸�");
		Class cl1 = person.getClass();
		System.out.println(cl1);
		
		Class cl2 = Person.class;
		System.out.println(cl2.getName());//getName()�� �Ⱦ��� �ٸ����̶� ���̳���
		
		Class cl3;
		try {
			cl3 = Class.forName("classClass.Person");
			System.out.println(cl3);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
