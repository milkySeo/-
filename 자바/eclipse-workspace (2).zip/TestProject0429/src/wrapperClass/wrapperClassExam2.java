package wrapperClass;

public class wrapperClassExam2 {

	public static void main(String[] args) {
		Integer num1 = 1;
		Integer num2 = 3;
		
		System.out.println(num1 + num2);
		System.out.println(num1 * num2);
		
		int num3 = 1;
		int num4 = 3;
		
		System.out.println(num3 + num4);
		System.out.println(num3 * num4);
		
		//�������� �ѹ��
//		Integer num1 = 1;
//		Integer num2 = 3;
//		Integer nSum = num1 + num2;
//		Integer nMultiple = num1 * num2;
//		
//		System.out.println(nSum);
//		System.out.println(nMultiple);
//		
//		int num3 = 1;
//		int num4 = 3;
//		int sum = num3 + num4;
//		int multiple = num3 + num4;
//		System.out.println(sum);
//		System.out.println(multiple);
		
		
	}

}
