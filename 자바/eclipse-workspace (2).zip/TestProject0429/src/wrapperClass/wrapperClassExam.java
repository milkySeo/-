package wrapperClass;

public class wrapperClassExam {

	public static void main(String[] args) {
		String str1 = "29";
		String str2 = "31.9";
		
		int num1 = Integer.parseInt(str1);
		double num2 = Double.parseDouble(str2);
		//double total = Integer.parseInt(str1) + Double.parseDouble(str2);
		//double total1 = Double.parseDouble(str1) + Double.parseDouble(str2);
		
		System.out.println(num1 + num2);
	}

}
