package Generic;

public class EmployeeInfo {

	public int rank;
	
	public EmployeeInfo(int rank) {
		this.rank = rank;
	}
	
}
