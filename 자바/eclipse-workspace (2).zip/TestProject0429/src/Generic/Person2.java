package Generic;

public class Person2<T, S> {

	public T info;
	public S id;
	
	public Person2(T info, S id) {
		this.info = info;
		this.id = id;
	}
	
	public <U> void printinfo(U info) {
		System.out.println(info);
	}
}
