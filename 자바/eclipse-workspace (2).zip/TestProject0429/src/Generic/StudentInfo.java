package Generic;

public class StudentInfo {

	public int grade;
	
	
	public StudentInfo(int grade) {
		this.grade = grade;
	}
	
	
	
}
