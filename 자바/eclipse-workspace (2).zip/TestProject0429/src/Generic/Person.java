package Generic;

public class Person<T> {

	public T info;
	
	public Person(T info) {
		this.info = info;
	}
	
}
