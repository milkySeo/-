package arrayList;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListExam2 {

	public static void main(String[] args) {

		ArrayList<Integer> arrayList1 = new ArrayList<Integer>();
		for(int i = 1; i < 11; i++) {
			arrayList1.add(i);
		}
//		//�̰� ��� �̰͵� ����									 Arraysġ�� ctrl + spaceBar �ϱ�
//		ArrayList<Integer> arrayList1 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6,7,8,9,10));

		for(int i = 0; i < arrayList1.size(); i++) {
			//System.out.println(arrayList1.get(i));

		}
		arrayList1.set(3, 7);
		arrayList1.set(9, 7);
		
		for(int i = 0; i < arrayList1.size(); i++) {
			System.out.println(arrayList1.get(i));
		}
		
		arrayList1.remove(4);
		arrayList1.remove(2);
		
		System.out.println("=====������=====");
		for(int i = 0; i < arrayList1.size(); i++) {
			System.out.println(arrayList1.get(i));
		}
	}

}
