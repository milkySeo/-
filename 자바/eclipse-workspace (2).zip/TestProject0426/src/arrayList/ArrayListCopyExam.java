package arrayList;

import java.util.ArrayList;

public class ArrayListCopyExam {

	public static void main(String[] args) {

		ArrayList<Integer> arrayList1 = new ArrayList<>();
		ArrayList<Integer> arrayList2 = new ArrayList<>();
		
		for(int i = 0; i < 10 ; i++) {
			arrayList1.add((i+1)*10);
			//System.out.println(arrayList1.get(i));
		}
		
		//��������
//		arrayList2 = arrayList1;
		
		//��������
		//1.
//		arrayList2.addAll(arrayList1);
		//2.
//		arrayList2 = (ArrayList<Integer>) arrayList1.clone();
		//3.
		for(int i = 0; i < arrayList1.size(); i++) {
			arrayList2.add(arrayList1.get(i));
		}
		
		arrayList1.set(2, 33);
		arrayList1.remove(7);
		
		System.out.println("========arrayList1========");
		for(int i = 0; i < arrayList1.size(); i++) {
			System.out.println(arrayList1.get(i));
		}
		System.out.println("========arrayList2========");
		for(int i = 0; i < arrayList2.size(); i++) {
			System.out.println(arrayList2.get(i));
		}
		
	}

}
