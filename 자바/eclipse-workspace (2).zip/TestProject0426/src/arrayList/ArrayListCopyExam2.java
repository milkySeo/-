package arrayList;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayListCopyExam2 {

	public static void main(String[] args) {

		ArrayList<String> arrayList1 = new ArrayList<String>(Arrays.asList("Java", "Android", "C", "Javascript"));
		
		for(String value : arrayList1) {
			System.out.println(value);
		}
	}

}
