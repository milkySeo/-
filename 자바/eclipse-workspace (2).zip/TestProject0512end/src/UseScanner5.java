import java.util.Scanner;

public class UseScanner5 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("���� �Է��ϼ���");
		int a = scan.nextInt();
		
		if(a == 3 || a == 4 || a == 5) {
			System.out.println("��");
		}
		else if(a == 6 || a == 7 || a == 8) {
			System.out.println("����");
		}
		else if(a == 9 || a == 10 || a == 11) {
			System.out.println("����");
		}
		else if(a == 12 || a == 1 || a == 2) {
			System.out.println("�ܿ�");
		}
		else {
			System.out.println("�߸��Է�");
		}
	}

}
