
public class Exam1 {

	public static void main(String[] args) {
//		int sum = 0, i = 1;
//		
//		while(i < 100) {
//			if(i % 3 != 0) {
//				i++;
//			continue;
//			}
//			else {
//				sum += i;
//				i++;
//			}
//		}
//		System.out.println(sum);
//		
//		int n[3] = new int[3];
//		int[] array = {1,2,3,4,5};
//		
//		array[array.length] = 100;
//		
		
//		String[] c = {"��","��","��","��","��","��","��","��","��","��"};
//		int[] n = {1,2,3,4,5};
//		char[] day = {'��','��','ȭ', '��', '��', '��', '��'};
//		
//		boolean[] bool = {true, false, false, true};
//		double[][] d = new double[5][4];
//		
		int[][] val = new int[4][3];
		
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 3; j++) {
				
				val[i][j] = i * 3 + j + 1;
				System.out.println(val[i][j]);
			}
		}
		//arraylist�� list�� ����
//		for(int value : val) {
//			System.out.println(value);
//		}
		
		
	}

}
