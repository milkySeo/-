import java.util.Scanner;

public class UseScanner1 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("a : ");
		int a = scanner.nextInt();
		System.out.print("b : ");
		int b = scanner.nextInt();
		System.out.print("c : ");
		int c = scanner.nextInt();
		
		if(a < b) {
			if(a < c) {
				if(b < c) {
					System.out.println("�߰����� b ; " +b);
				}
				else if(c < b) {
					System.out.println("�߰����� c ; " +c);
				}
			}
			else if(c < a) {
				System.out.println("�߰����� a ; " +a);
			}
			
		}
		else if(b < a) {
			if(a < c) {
				System.out.println("�߰����� a ; " +a);
				
			}
			else if(c < a) {
				if(b < c) {
					System.out.println("�߰����� c ; " +c);
				}
				else if(c < b) {
					System.out.println("�߰����� b ; " +b);
				}
				
			}
		}
	}
}
