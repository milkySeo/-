
public class Exam2 {

	public static void main(String[] args) {
		int n[][] = {{1},{1,2,3},{1},{1,2,3,4},{1,2}};
		for(int i = 0; i < n.length; i++) {
			System.out.println(n[i].length);
		}
		
		double d[][] = {{1.1, 1.2, 1.2, 1.4},{2.1, 2.2},{3.1, 3.2, 1.2},{4.1}};
		
	}

}
