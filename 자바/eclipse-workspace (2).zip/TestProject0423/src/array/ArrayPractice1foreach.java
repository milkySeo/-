package array;

public class ArrayPractice1foreach {

	public static void main(String[] args) {

		int[] array = {10, 20, 30, 40, 50};
		for(int value : array) {
			System.out.println(value);
		}
		
		System.out.println("===================");
		
		double[] array2 = {10.2, 13.4, 14.2};
		for(double value : array2) {
			System.out.println(value);
		}
		
		System.out.println("===================");

		String[] strArray = {"Java", "Android", "C", "Javascript"};
		for(String value : strArray) {
			System.out.println(value);
		}
		
		System.out.println("===================");

	}

}
