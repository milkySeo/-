import java.util.Scanner;

public class Test3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int[] n = new int[10];
		
		for(int i = 0; i < 10; i++) {
			n[i] = scan.nextInt();
		}
		
//		for(int value : n) {
//			System.out.println(value);
//		}
		
		
		for(int i = 0; i < 10; i++) {
			if(n[i] % 3 == 0) {
				System.out.println(n[i]);
			}
		}
		
		
		
	}

}
