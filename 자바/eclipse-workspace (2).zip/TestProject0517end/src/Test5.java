
public class Test5 {

	public static void main(String[] args) {
		int[] n = new int[10];
		int sum = 0;
		int avg = 0;
		
		for(int i = 0; i < 10; i++) {
			n[i] = (int)(Math.random()*10+1);
		}
		
		System.out.print("������ ������ : ");
		for(int value : n) {
			System.out.print(value + " ");
		}
		System.out.println();
		for(int i = 0; i < n.length; i++) {
			
			sum = sum + n[i];
			avg = sum / n.length;
		}
		System.out.println("��հ� : " + avg);
	}

}
