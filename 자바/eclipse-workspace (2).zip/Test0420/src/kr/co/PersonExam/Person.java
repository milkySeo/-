package kr.co.PersonExam;

public class Person {

	String name;
	int weight;
	int height;
	char gender;
	
	
	public Person() {
//		this.name = "�̸�����";
//		this.height = 0;
//		this.weight = 0;
		this("�̸�����", 0, 0);//this.Person() �� �ƴϰ�!!!!!!
	}
	
	public Person(String name, int height, int weight) {
		this.name = name;
		this.height = height;
		this.weight = weight;
	}
	
	
	
}
