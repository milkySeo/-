package kr.co.PersonExam;

public class UsePerson {

	public static void main(String[] args) {
//		Person person = new Person("������", 'F');
//		
//		System.out.println("�̸� : " + person.name + "\n" + "���� : " + person.gender);
		
		Person person2 = new Person();
		System.out.println("�̸� : " + person2.name);
		System.out.println("Ű : " + person2.height);
		System.out.println("������ : " + person2.weight);
		
		
	}

}
