package kr.co.CarExam;

import kr.co.PersonExam.Person;

public class Car {

	String name=" �̸�";
	int speed;
	
	public void run() {
		System.out.println("���� �޸��ϴ�.");
	}
	
	public void run(int a) {
		System.out.println(a + "���� �޷���.");
	}
	
	public void name(String name) {
		this.name = name;
		System.out.println(name);
	}
	Person person = new Person();
	

}
