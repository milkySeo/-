package kr.co.CarExam;

public class UseCar {

	public static void main(String[] args) {
	//Car car = new Car("bmw");
	//System.out.println(car.name);
	
	Car car = new Car();
	//car.run(1);
	System.out.println(car.name);
	//car.name();
	
	

	}

}
