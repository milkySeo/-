
public class MakeFood {

	public static void main(String[] args) {
		Food food = new Food(1000,"���");
		
		System.out.println(food.price);
		System.out.println(food.name);
		

	}

}
