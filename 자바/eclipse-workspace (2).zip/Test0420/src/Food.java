
public class Food {

	int price;
	String name;
	
	
	public Food(int price,String name) {
		this.price = price;
		this.name = name;
		
	}
}
