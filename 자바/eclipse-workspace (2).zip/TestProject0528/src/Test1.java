import java.util.Scanner;

public class Test1 {
	
	
	
	
	
	public static int sum() {
		int sum = 0;
		for(int i = 1; i < 101; i++) {
			sum += i;
		}
		return sum;
	}
	
	public static int sum1(int n) {
		int sum1 = 0;
		for(int i = 1; i < n; i++) {
			if(i % 2 == 0) {
				sum1 += i;
			}
		}
		return sum1;
	}
	
	public static void sum2() {
		int sum2 = 0;
		for(int i = 1; i < 101; i++) {
			if(i % 2 == 1) {
				sum2 += i;
			}
		}
		System.out.println(sum2);
	}
	
	public static void main(String[] args) {
		
		System.out.println(sum());
		
		Scanner scan = new Scanner(System.in);
		
		int a = scan.nextInt();
		System.out.println("���� �Է��ϼ���");
		
		System.out.println(sum1(a));
		
		sum2();
	
	}
}
