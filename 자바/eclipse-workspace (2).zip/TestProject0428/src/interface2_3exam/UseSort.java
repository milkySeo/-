package interface2_3exam;

public class UseSort {

	public static void main(String[] args) {
		int[] array = {1,4,7,9,2,5,3,8,10};
		
		Sort hSort = new HeapSort();
		hSort.ascending(array);
		hSort.desending(array);
		hSort.description();
		
		
		Sort qSort = new QuickSort();
		qSort.ascending(array);
		qSort.desending(array);
		qSort.description();
	}

}
