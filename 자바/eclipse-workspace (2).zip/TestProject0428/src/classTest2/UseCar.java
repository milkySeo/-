package classTest2;

public class UseCar {

	public static void main(String[] args) {
		Car car = new Car();
		String str1 = new String("Ab");
		String str2 = new String("Ab");
		System.out.println(str1.hashCode());
		System.out.println(str1.hashCode());
		
		Integer i1 = new Integer(1);
		Integer i2 = new Integer(2);
		System.out.println(i1.hashCode());
		System.out.println(i2.hashCode());
	}

}
