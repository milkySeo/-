package classTest2;

public class Car {
	String car;
	
	
	
}
