package objectClassExam;

public class MyDate {
	int day;
	int month;
	int year;
	
	public MyDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof MyDate) {
			MyDate date = (MyDate)obj; 
			if(this.day == date.day && this.month == date.month && this.year == date.year) {
				//this.day => date1 �� day //date.day = date2�� day
				return true;
			}
			else {
				return false;
			}
		}
		
		return false;
	}
	
	
}
