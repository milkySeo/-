
public class SongExam {

	public static void main(String[] args) {
		Song song1 = new Song();
		song1.songTitle = "�뷡����";
		song1.singer = "����";
		song1.albumName = "�ٹ��̸�";
		song1.trackNumber = 1;

		
		System.out.println(song1.songTitle);
		System.out.println(song1.singer);
		System.out.println(song1.albumName);
		System.out.println(song1.trackNumber);
		song1.songInfo();
		
	}

}
