
public class AddMethod {

	public static void main(String[] args) {
		int sum = add(1,2);
		System.out.println(sum);
		
		printJava();
		
		method(3);
		
		int c = no();
		System.out.println(c);
		
	}
	
		static int add(int number1, int number2) {
			int result = number1 + number2;
			return result;	
		}
		
		static void printJava() {
			System.out.println("hi");
		}
		
		static void method(int a) {
			System.out.println(a);
		}
		
		static int no() {
			return 10;
		}
		
		static void method2(int a, int b) {
			
		}

		
}
