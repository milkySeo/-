
public class Student {
	String studentName;
	String grade;
	String address;
	
	void showStudentInfo() {
		System.out.println(studentName);
		System.out.println(address);
		
	}
}
