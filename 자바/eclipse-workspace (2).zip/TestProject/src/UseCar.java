
public class UseCar {

	public static void main(String[] args) {
		
		Car car1 = new Car();
		car1.color = "red";
		car1.gear = 1;
		car1.number = 1000;
		car1.speed = 80;
		
		Car car2 = new Car();
		car2.color = "blue";
		car2.gear = 2;
		car2.number = 2000;
		car2.speed = 90;
		
		Car car3 = new Car(); 
		car3.color = "red";
		car3.gear = 1;
		car3.number = 1000;
		car3.speed = 80;
		
		System.out.println(car1.color);
		System.out.println(car1.gear);
		System.out.println(car1.number);
		System.out.println(car1.speed);
		
		System.out.println(car2.color);
		System.out.println(car2.gear);
		System.out.println(car2.number);
		System.out.println(car2.speed);
		
		
	}

}
