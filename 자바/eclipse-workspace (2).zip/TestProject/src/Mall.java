
public class Mall {

	long num;
	String id;
	String date;
	String name;
	String address;
}
