
public class Calc {
	static int plus(int num1, int num2) {
		int result = num1 + num2;
		return result;
	}
	static int minus(int num1, int num2) {
		int result = num1 - num2;
		return result;
	}
	
	static int division(int num1, int num2) {
		int result = num1/num2;
		return result;
	}
	
	public static void main(String[] args) {
		int result1 = plus(3,1);
		int result2 = minus(4,2);
		int result3 = division(8,2);
		
		
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);
	}
	
}
/////////�������� �Ѱ� ���ο� Ŭ���� ���� 
//public class UseCalc {
//	public static void main(String[] args) {
//		Calc calc = new Calc();  ���� Ŭ������ �Ҵ�޾Ƽ� �ϴµ�..
//		
//		int addResult = calc.add(5, 2);
//		int minusResult = calc.minus(5, 2);
//		int devideResult = calc.divide(5, 2);
//		
//		System.out.println("addResult : " + addResult);
//		System.out.println("minusResult : " + minusResult);
//		System.out.println("devideResult : " + devideResult);
//		
//	}
//}

