
public class Car {
	
	int number;
	int speed;
	String color;
	int gear;
	
}
