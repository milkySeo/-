
public class People {

	String name;
	int height;
	int weight;
	String sex;
	boolean marital;
}
