
public class UsePeople {

	public static void main(String[] args) {
		People people1 = new People();
		people1.name = "�̸�";
		people1.height = 170;
		people1.weight = 60;
		people1.sex = "female";
		people1.marital = false;

	}

}
