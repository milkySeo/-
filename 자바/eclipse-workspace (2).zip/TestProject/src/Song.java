
public class Song {
	
	String songTitle;
	String singer;
	String albumName;
	int trackNumber;
	
	void songInfo() {
		
		System.out.println("�뷡���� : " + songTitle);
		System.out.println("�ٹ��̸� : " + albumName);
		
	}
}
